Valve3.ax -filtr
PStart.exe -zdalne polecenie startu
PEnd.exe -zdalne polecenie zatrzymania

zadalne polecenia nalezy wydawac z adresem IP jako parametrem
przyklad:
c:\PStart.exe 192.168.14.242
